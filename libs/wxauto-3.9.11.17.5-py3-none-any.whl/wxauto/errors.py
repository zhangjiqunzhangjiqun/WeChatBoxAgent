
class TargetNotFoundError(Exception):
    pass

class FriendNotFoundError(Exception):
    pass